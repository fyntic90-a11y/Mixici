package com.guner.os.vm

import android.app.Application
import androidx.datastore.preferences.core.Preferences
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.guner.os.data.AppInfo
import com.guner.os.data.AppRepository
import com.guner.os.data.GunerSettings
import com.guner.os.data.SK
import com.guner.os.data.SettingsStore
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class LauncherViewModel(application: Application) : AndroidViewModel(application) {
    val repo = AppRepository(application)
    private val store = SettingsStore(application)

    val settings: StateFlow<GunerSettings> =
        store.flow.stateIn(viewModelScope, SharingStarted.Eagerly, GunerSettings())

    private val _apps = MutableStateFlow<List<AppInfo>>(emptyList())
    val apps: StateFlow<List<AppInfo>> = _apps.asStateFlow()

    private val _home = MutableStateFlow(0)
    val homeSignal: StateFlow<Int> = _home.asStateFlow()

    init {
        viewModelScope.launch { _apps.value = repo.loadApps() }
    }

    fun goHome() {
        _home.value = _home.value + 1
    }

    fun reload() {
        viewModelScope.launch {
            val list = repo.loadApps()
            _apps.value = list
            prune(list)
        }
    }

    /** Первый запуск: заполняем док и первую страницу рабочего стола. */
    fun bootstrap() {
        viewModelScope.launch {
            val list = repo.loadApps()
            _apps.value = list
            val s = store.flow.first()
            if (!s.layoutInit) {
                val dock = repo.defaultDockKeys(list).take(5)
                val rest = list.filter { it.key !in dock }.take(12).map { it.key }
                store.saveLayout(listOf(rest), dock)
            } else {
                prune(list)
            }
        }
    }

    private suspend fun prune(list: List<AppInfo>) {
        if (list.isEmpty()) return
        val s = store.flow.first()
        if (!s.layoutInit) return
        val keys = list.map { it.key }.toHashSet()
        val np = s.pages.map { p -> p.filter { it in keys } }
        val nd = s.dock.filter { it in keys }
        if (np != s.pages || nd != s.dock) store.saveLayout(np, nd)
    }

    fun <T> put(key: Preferences.Key<T>, value: T) {
        viewModelScope.launch { store.set(key, value) }
    }

    private fun editLayout(block: (MutableList<MutableList<String>>, MutableList<String>) -> Unit) {
        viewModelScope.launch {
            val s = store.flow.first()
            val pages = s.pages.map { it.toMutableList() }.toMutableList()
            if (pages.isEmpty()) pages.add(mutableListOf())
            val dock = s.dock.toMutableList()
            block(pages, dock)
            store.saveLayout(pages, dock)
        }
    }

    fun addToHome(key: String) {
        val cap = settings.value.cols * settings.value.rows
        editLayout { pages, _ ->
            if (pages.none { key in it }) {
                val p = pages.firstOrNull { it.size < cap }
                if (p != null) p.add(key) else pages.add(mutableListOf(key))
            }
        }
    }

    fun removeFromHome(key: String) {
        editLayout { pages, _ -> pages.forEach { it.remove(key) } }
    }

    fun addToDock(key: String) {
        editLayout { _, dock -> if (key !in dock && dock.size < 5) dock.add(key) }
    }

    fun removeFromDock(key: String) {
        editLayout { _, dock -> dock.remove(key) }
    }

    fun addPage() {
        editLayout { pages, _ -> pages.add(mutableListOf()) }
    }

    fun removePage(index: Int) {
        editLayout { pages, _ ->
            if (pages.size > 1 && index in pages.indices && pages[index].isEmpty()) pages.removeAt(index)
        }
    }

    fun hide(key: String) {
        editLayout { pages, dock ->
            pages.forEach { it.remove(key) }
            dock.remove(key)
        }
        put(SK.hidden, settings.value.hidden + key)
    }

    fun unhide(key: String) {
        put(SK.hidden, settings.value.hidden - key)
    }
}
