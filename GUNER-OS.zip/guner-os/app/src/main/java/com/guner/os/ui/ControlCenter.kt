package com.guner.os.ui

import android.content.Context
import android.media.MediaMetadata
import android.media.session.PlaybackState
import android.provider.Settings
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AirplanemodeActive
import androidx.compose.material.icons.rounded.BatterySaver
import androidx.compose.material.icons.rounded.Bluetooth
import androidx.compose.material.icons.rounded.BrightnessMedium
import androidx.compose.material.icons.rounded.FlashlightOn
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.ScreenRotation
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.SignalCellularAlt
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material.icons.rounded.VolumeUp
import androidx.compose.material.icons.rounded.Wifi
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.guner.os.system.MediaCtl
import com.guner.os.system.SystemControls
import com.guner.os.system.Torch
import com.guner.os.system.startSafe
import android.content.Intent
import kotlinx.coroutines.delay
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale

private class Tile(
    val icon: ImageVector,
    val label: String,
    val on: Boolean,
    val onLong: () -> Unit,
    val onClick: () -> Unit,
)

private fun openSettings(ctx: Context, action: String) = startSafe(ctx, Intent(action))

@Composable
fun ControlCenter(
    progress: () -> Float,
    onClose: () -> Unit,
    onOpenSettings: () -> Unit,
) {
    val ctx = LocalContext.current
    LaunchedEffect(Unit) { Torch.init(ctx) }
    var tick by remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(700)
            tick++
        }
    }
    val wifi = remember(tick) { SystemControls.wifiOn(ctx) }
    val bt = remember(tick) { SystemControls.btOn(ctx) }
    val cell = remember(tick) { SystemControls.cellularActive(ctx) }
    val air = remember(tick) { SystemControls.airplane(ctx) }
    val saver = remember(tick) { SystemControls.powerSave(ctx) }
    val rot = remember(tick) { SystemControls.autoRotate(ctx) }
    val canWrite = remember(tick) { SystemControls.canWrite(ctx) }
    val battery = remember(tick) { SystemControls.batteryPercent(ctx) }
    val charging = remember(tick) { SystemControls.charging(ctx) }
    var brightness by remember { mutableFloatStateOf(SystemControls.brightness(ctx).toFloat()) }
    var volume by remember { mutableFloatStateOf(SystemControls.volume(ctx).toFloat()) }
    val maxVol = remember { SystemControls.maxVolume(ctx).coerceAtLeast(1) }

    val internetPanel = {
        startSafe(ctx, Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY))
    }
    val tiles = listOf(
        Tile(Icons.Rounded.Wifi, "Wi‑Fi", wifi, { openSettings(ctx, Settings.ACTION_WIFI_SETTINGS) }, { internetPanel() }),
        Tile(Icons.Rounded.Bluetooth, "Bluetooth", bt, { openSettings(ctx, Settings.ACTION_BLUETOOTH_SETTINGS) }, { openSettings(ctx, Settings.ACTION_BLUETOOTH_SETTINGS) }),
        Tile(Icons.Rounded.SignalCellularAlt, "Моб. сеть", cell, { openSettings(ctx, Settings.ACTION_DATA_ROAMING_SETTINGS) }, { internetPanel() }),
        Tile(Icons.Rounded.AirplanemodeActive, "Авиарежим", air, { openSettings(ctx, Settings.ACTION_AIRPLANE_MODE_SETTINGS) }, { openSettings(ctx, Settings.ACTION_AIRPLANE_MODE_SETTINGS) }),
        Tile(Icons.Rounded.FlashlightOn, "Фонарик", Torch.on, {}, {
            if (!Torch.toggle(ctx)) android.widget.Toast.makeText(ctx, "Вспышка недоступна", android.widget.Toast.LENGTH_SHORT).show()
        }),
        Tile(Icons.Rounded.ScreenRotation, "Автоповорот", rot, { openSettings(ctx, Settings.ACTION_DISPLAY_SETTINGS) }, {
            SystemControls.setAutoRotate(ctx, !rot)
            tick++
        }),
        Tile(Icons.Rounded.BatterySaver, "Экономия", saver, { openSettings(ctx, Settings.ACTION_BATTERY_SAVER_SETTINGS) }, { openSettings(ctx, Settings.ACTION_BATTERY_SAVER_SETTINGS) }),
        Tile(Icons.Rounded.Settings, "GUNER", false, { openSettings(ctx, Settings.ACTION_SETTINGS) }, { onOpenSettings() }),
    )

    Box(
        Modifier
            .fillMaxSize()
            .drawBehind { drawRect(Color.Black.copy(alpha = 0.45f * progress())) }
            .pointerInput(Unit) { detectTapGestures(onTap = { onClose() }) }
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .graphicsLayer { translationY = -(1f - progress()) * size.height }
                .pointerInput(Unit) { detectTapGestures { } }
                .pointerInput(Unit) {
                    var total = 0f
                    val threshold = 48.dp.toPx()
                    detectVerticalDragGestures(
                        onDragStart = { total = 0f },
                        onDragEnd = { if (total < -threshold) onClose() },
                        onDragCancel = {},
                        onVerticalDrag = { _, dy -> total += dy },
                    )
                },
            shape = RoundedCornerShape(bottomStart = 36.dp, bottomEnd = 36.dp),
            color = MaterialTheme.colorScheme.surface.copy(alpha = 0.95f),
        ) {
            Column(
                Modifier.statusBarsPadding().padding(horizontal = 16.dp, vertical = 16.dp).navigationBarsPadding()
            ) {
                Header(battery, charging)
                Spacer(Modifier.height(16.dp))
                tiles.chunked(4).forEach { row ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        row.forEach { TileView(it) }
                    }
                    Spacer(Modifier.height(12.dp))
                }
                if (canWrite) {
                    SliderPanel(Icons.Rounded.BrightnessMedium, brightness, 255f, 1f) { v ->
                        brightness = v
                        SystemControls.setBrightness(ctx, v.toInt())
                    }
                } else {
                    PermissionPanel("Разрешить управление яркостью") { SystemControls.requestWrite(ctx) }
                }
                Spacer(Modifier.height(12.dp))
                SliderPanel(Icons.Rounded.VolumeUp, volume, maxVol.toFloat(), 0f) { v ->
                    volume = v
                    SystemControls.setVolume(ctx, v.toInt())
                }
                Spacer(Modifier.height(12.dp))
                MusicCard(ctx, tick)
            }
        }
    }
}

@Composable
private fun Header(battery: Int, charging: Boolean) {
    val now = remember { LocalDateTime.now() }
    val time = now.format(DateTimeFormatter.ofPattern("HH:mm", Locale.getDefault()))
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(time, fontSize = 34.sp, fontWeight = FontWeight.Light, color = MaterialTheme.colorScheme.onSurface)
        Spacer(Modifier.weight(1f))
        if (battery >= 0) {
            Text(
                (if (charging) "⚡ " else "") + "$battery%",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontSize = 16.sp,
            )
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun RowScope.TileView(t: Tile) {
    val bg by animateColorAsState(
        if (t.on) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f),
        label = "tile",
    )
    val fg = if (t.on) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface
    Column(
        Modifier
            .weight(1f)
            .aspectRatio(1f)
            .clip(RoundedCornerShape(24.dp))
            .background(bg)
            .combinedClickable(onClick = t.onClick, onLongClick = t.onLong),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Icon(t.icon, contentDescription = t.label, tint = fg)
        Spacer(Modifier.height(6.dp))
        Text(t.label, color = fg, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun SliderPanel(icon: ImageVector, value: Float, max: Float, min: Float, onChange: (Float) -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(24.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f))
            .padding(horizontal = 16.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.onSurface)
        Slider(
            value = value.coerceIn(min, max),
            onValueChange = onChange,
            valueRange = min..max,
            modifier = Modifier.weight(1f).padding(start = 8.dp),
        )
    }
}

@Composable
private fun PermissionPanel(text: String, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(24.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f))
            .clickable(onClick = onClick)
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(Icons.Rounded.BrightnessMedium, contentDescription = null)
        Spacer(Modifier.width(12.dp))
        Text(text, color = MaterialTheme.colorScheme.onSurface)
    }
}

@Composable
private fun MusicCard(ctx: Context, tick: Int) {
    val access = remember(tick) { MediaCtl.hasAccess(ctx) }
    val mc = remember(tick) { if (access) MediaCtl.controller(ctx) else null }
    val title = mc?.metadata?.getString(MediaMetadata.METADATA_KEY_TITLE)
    val artist = mc?.metadata?.getString(MediaMetadata.METADATA_KEY_ARTIST)
    val playing = mc?.playbackState?.state == PlaybackState.STATE_PLAYING

    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(24.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f))
            .then(
                if (!access) Modifier.clickable {
                    openSettings(ctx, Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)
                } else Modifier
            )
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(Icons.Rounded.MusicNote, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                when {
                    !access -> "Включить управление музыкой"
                    mc == null -> "Ничего не играет"
                    else -> title ?: "Без названия"
                },
                color = MaterialTheme.colorScheme.onSurface, maxLines = 1, overflow = TextOverflow.Ellipsis,
                fontWeight = FontWeight.Medium,
            )
            Text(
                when {
                    !access -> "Нужен доступ к уведомлениям — нажмите"
                    else -> artist ?: ""
                },
                color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp, maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
        if (mc != null) {
            IconButton(onClick = { mc.transportControls.skipToPrevious() }) {
                Icon(Icons.Rounded.SkipPrevious, contentDescription = "Назад")
            }
            IconButton(onClick = { if (playing) mc.transportControls.pause() else mc.transportControls.play() }) {
                Icon(if (playing) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, contentDescription = "Пауза/Играть")
            }
            IconButton(onClick = { mc.transportControls.skipToNext() }) {
                Icon(Icons.Rounded.SkipNext, contentDescription = "Вперёд")
            }
        }
    }
}
