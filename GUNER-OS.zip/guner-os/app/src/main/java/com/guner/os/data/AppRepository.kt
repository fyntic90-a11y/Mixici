package com.guner.os.data

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.AdaptiveIconDrawable
import android.graphics.drawable.Drawable
import android.net.Uri
import android.provider.MediaStore
import android.util.LruCache
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class AppInfo(
    val key: String,
    val label: String,
    val packageName: String,
    val component: ComponentName,
)

class AppRepository(context: Context) {
    private val ctx = context.applicationContext
    private val pm: PackageManager = ctx.packageManager

    // ~100 иконок * 144*144*4 байта ≈ 8 МБ. Иконки грузятся лениво, только для видимых элементов.
    private val cache = LruCache<String, ImageBitmap>(100)

    fun cached(key: String): ImageBitmap? = cache.get(key)

    fun clearIcons() = cache.evictAll()

    suspend fun loadApps(): List<AppInfo> = withContext(Dispatchers.IO) {
        val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        pm.queryIntentActivities(q, 0).mapNotNull { ri ->
            val ai = ri.activityInfo ?: return@mapNotNull null
            if (ai.packageName == ctx.packageName && ai.name.endsWith("MainActivity")) return@mapNotNull null
            val cn = ComponentName(ai.packageName, ai.name)
            AppInfo(cn.flattenToString(), ri.loadLabel(pm).toString(), ai.packageName, cn)
        }.sortedBy { it.label.lowercase() }
    }

    suspend fun icon(app: AppInfo): ImageBitmap {
        cache.get(app.key)?.let { return it }
        return withContext(Dispatchers.IO) {
            val d = try {
                pm.getActivityIcon(app.component)
            } catch (e: Exception) {
                pm.defaultActivityIcon
            }
            d.toBitmap(ICON_PX).asImageBitmap().also { cache.put(app.key, it) }
        }
    }

    /** Дефолтные приложения для дока: телефон, сообщения, браузер, камера. */
    fun defaultDockKeys(apps: List<AppInfo>): List<String> {
        val intents = listOf(
            Intent(Intent.ACTION_DIAL),
            Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:")),
            Intent(Intent.ACTION_VIEW, Uri.parse("https://example.com")),
            Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA),
        )
        return intents.mapNotNull { i ->
            val pkg = pm.queryIntentActivities(i, PackageManager.MATCH_DEFAULT_ONLY)
                .firstOrNull()?.activityInfo?.packageName
            apps.firstOrNull { it.packageName == pkg }?.key
        }.distinct()
    }

    private fun Drawable.toBitmap(px: Int): Bitmap {
        val bmp = Bitmap.createBitmap(px, px, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        if (this is AdaptiveIconDrawable) {
            // Рисуем слои без системной маски — форму задаёт GUNER (настройка «Иконки»).
            val o = (px * 0.25f).toInt()
            background?.let { it.setBounds(-o, -o, px + o, px + o); it.draw(c) }
            foreground?.let { it.setBounds(-o, -o, px + o, px + o); it.draw(c) }
        } else {
            setBounds(0, 0, px, px)
            draw(c)
        }
        return bmp
    }

    companion object {
        private const val ICON_PX = 144
    }
}
