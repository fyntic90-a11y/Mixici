package com.guner.os

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.runtime.getValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.guner.os.ui.GunerTheme
import com.guner.os.ui.settings.SettingsApp
import com.guner.os.vm.LauncherViewModel

class SettingsActivity : ComponentActivity() {
    private val vm: LauncherViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        setContent {
            val s by vm.settings.collectAsStateWithLifecycle()
            GunerTheme(s) {
                SettingsApp(vm = vm, s = s, onExit = { finish() })
            }
        }
    }
}
