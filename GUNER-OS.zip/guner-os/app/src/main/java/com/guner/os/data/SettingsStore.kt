package com.guner.os.data

import android.content.Context
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.gunerDataStore by preferencesDataStore(name = "guner_settings")

data class GunerSettings(
    val themeMode: Int = 0,          // 0 система, 1 светлая, 2 тёмная
    val dynamicColor: Boolean = true,
    val accent: Int = 0,
    val wallpaperMode: Int = 0,      // 0 системные, 1 GUNER
    val wallpaperStyle: Int = 0,
    val cols: Int = 4,
    val rows: Int = 5,
    val iconSize: Int = 56,
    val iconShape: Int = 1,          // 0 круг, 1 сквиркл, 2 квадрат
    val showLabels: Boolean = true,
    val showClock: Boolean = true,
    val animScale: Float = 1f,
    val launchAnim: Boolean = true,
    val perfMode: Int = 1,           // 0 производительность, 1 баланс, 2 красота
    val swipeUp: Int = 1,            // 0 ничего, 1 приложения, 2 центр управления, 3 настройки
    val swipeDown: Int = 2,
    val hidden: Set<String> = emptySet(),
    val layoutInit: Boolean = false,
    val pages: List<List<String>> = listOf(emptyList()),
    val dock: List<String> = emptyList(),
) {
    /** Множитель длительности анимаций: меньше — быстрее. */
    val animFactor: Float get() = animScale * if (perfMode == 0) 0.75f else 1f
}

object SK {
    val theme = intPreferencesKey("theme")
    val dynamic = booleanPreferencesKey("dynamic")
    val accent = intPreferencesKey("accent")
    val wpMode = intPreferencesKey("wp_mode")
    val wpStyle = intPreferencesKey("wp_style")
    val cols = intPreferencesKey("cols")
    val rows = intPreferencesKey("rows")
    val iconSize = intPreferencesKey("icon_size")
    val iconShape = intPreferencesKey("icon_shape")
    val labels = booleanPreferencesKey("labels")
    val clock = booleanPreferencesKey("clock")
    val animScale = floatPreferencesKey("anim_scale")
    val launchAnim = booleanPreferencesKey("launch_anim")
    val perf = intPreferencesKey("perf")
    val swipeUp = intPreferencesKey("swipe_up")
    val swipeDown = intPreferencesKey("swipe_down")
    val hidden = stringSetPreferencesKey("hidden")
    val layoutInit = booleanPreferencesKey("layout_init")
    val pages = stringPreferencesKey("pages")
    val dock = stringPreferencesKey("dock")
}

class SettingsStore(context: Context) {
    private val ctx = context.applicationContext

    val flow: Flow<GunerSettings> = ctx.gunerDataStore.data.map { p ->
        val d = GunerSettings()
        GunerSettings(
            themeMode = p[SK.theme] ?: d.themeMode,
            dynamicColor = p[SK.dynamic] ?: d.dynamicColor,
            accent = p[SK.accent] ?: d.accent,
            wallpaperMode = p[SK.wpMode] ?: d.wallpaperMode,
            wallpaperStyle = p[SK.wpStyle] ?: d.wallpaperStyle,
            cols = p[SK.cols] ?: d.cols,
            rows = p[SK.rows] ?: d.rows,
            iconSize = p[SK.iconSize] ?: d.iconSize,
            iconShape = p[SK.iconShape] ?: d.iconShape,
            showLabels = p[SK.labels] ?: d.showLabels,
            showClock = p[SK.clock] ?: d.showClock,
            animScale = p[SK.animScale] ?: d.animScale,
            launchAnim = p[SK.launchAnim] ?: d.launchAnim,
            perfMode = p[SK.perf] ?: d.perfMode,
            swipeUp = p[SK.swipeUp] ?: d.swipeUp,
            swipeDown = p[SK.swipeDown] ?: d.swipeDown,
            hidden = p[SK.hidden] ?: emptySet(),
            layoutInit = p[SK.layoutInit] ?: false,
            pages = decodePages(p[SK.pages]),
            dock = (p[SK.dock] ?: "").split(";").filter { it.isNotEmpty() },
        )
    }

    suspend fun <T> set(key: Preferences.Key<T>, value: T) {
        ctx.gunerDataStore.edit { it[key] = value }
    }

    suspend fun saveLayout(pages: List<List<String>>, dock: List<String>) {
        ctx.gunerDataStore.edit {
            it[SK.pages] = pages.joinToString("|") { p -> p.joinToString(";") }
            it[SK.dock] = dock.joinToString(";")
            it[SK.layoutInit] = true
        }
    }

    private fun decodePages(raw: String?): List<List<String>> {
        if (raw == null) return listOf(emptyList())
        return raw.split("|").map { p -> p.split(";").filter { it.isNotEmpty() } }
    }
}
