package com.guner.os.system

import android.app.ActivityOptions
import android.bluetooth.BluetoothManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.BatteryManager
import android.os.PowerManager
import android.provider.Settings
import android.view.View
import android.widget.Toast
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.geometry.Rect
import androidx.core.app.NotificationManagerCompat
import com.guner.os.data.AppInfo

fun startSafe(ctx: Context, intent: Intent) {
    try {
        ctx.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (e: Exception) {
        Toast.makeText(ctx, "Не удалось открыть", Toast.LENGTH_SHORT).show()
    }
}

fun launchApp(ctx: Context, view: View, app: AppInfo, bounds: Rect?, animate: Boolean) {
    val i = Intent(Intent.ACTION_MAIN)
        .addCategory(Intent.CATEGORY_LAUNCHER)
        .setComponent(app.component)
        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
    try {
        val opts = if (animate && bounds != null) {
            ActivityOptions.makeScaleUpAnimation(
                view, bounds.left.toInt(), bounds.top.toInt(), bounds.width.toInt(), bounds.height.toInt()
            ).toBundle()
        } else null
        ctx.startActivity(i, opts)
    } catch (e: Exception) {
        Toast.makeText(ctx, "Не удалось открыть ${app.label}", Toast.LENGTH_SHORT).show()
    }
}

/** Фонарик через CameraManager.setTorchMode — настоящее переключение, камера-разрешение не нужно. */
object Torch {
    var on by mutableStateOf(false)
    private var camId: String? = null
    private var registered = false

    fun init(context: Context) {
        if (registered) return
        registered = true
        val cm = context.applicationContext.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        try {
            camId = cm.cameraIdList.firstOrNull {
                cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            }
            cm.registerTorchCallback(object : CameraManager.TorchCallback() {
                override fun onTorchModeChanged(cameraId: String, enabled: Boolean) {
                    if (cameraId == camId) on = enabled
                }
            }, null)
        } catch (_: Exception) {
        }
    }

    fun toggle(context: Context): Boolean {
        val id = camId ?: return false
        return try {
            val cm = context.applicationContext.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            cm.setTorchMode(id, !on)
            true
        } catch (e: Exception) {
            false
        }
    }
}

object MediaCtl {
    fun hasAccess(ctx: Context): Boolean =
        NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName)

    fun controller(ctx: Context): MediaController? = try {
        val msm = ctx.getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager
        msm.getActiveSessions(ComponentName(ctx, GunerNotificationListener::class.java)).firstOrNull()
    } catch (e: Exception) {
        null
    }
}

object SystemControls {
    fun wifiOn(c: Context): Boolean = try {
        (c.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager).isWifiEnabled
    } catch (e: Exception) {
        false
    }

    fun btOn(c: Context): Boolean = try {
        (c.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter?.isEnabled == true
    } catch (e: Exception) {
        false
    }

    fun airplane(c: Context): Boolean =
        Settings.Global.getInt(c.contentResolver, Settings.Global.AIRPLANE_MODE_ON, 0) == 1

    fun powerSave(c: Context): Boolean =
        (c.getSystemService(Context.POWER_SERVICE) as PowerManager).isPowerSaveMode

    fun cellularActive(c: Context): Boolean = try {
        val cm = c.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        cm.getNetworkCapabilities(cm.activeNetwork)?.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) == true
    } catch (e: Exception) {
        false
    }

    fun autoRotate(c: Context): Boolean =
        Settings.System.getInt(c.contentResolver, Settings.System.ACCELEROMETER_ROTATION, 0) == 1

    fun canWrite(c: Context): Boolean = Settings.System.canWrite(c)

    fun requestWrite(c: Context) {
        startSafe(c, Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:${c.packageName}")))
    }

    fun setAutoRotate(c: Context, on: Boolean) {
        if (!canWrite(c)) return requestWrite(c)
        Settings.System.putInt(c.contentResolver, Settings.System.ACCELEROMETER_ROTATION, if (on) 1 else 0)
    }

    fun brightness(c: Context): Int =
        Settings.System.getInt(c.contentResolver, Settings.System.SCREEN_BRIGHTNESS, 128)

    fun setBrightness(c: Context, v: Int) {
        if (!canWrite(c)) return
        Settings.System.putInt(
            c.contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE,
            Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL
        )
        Settings.System.putInt(c.contentResolver, Settings.System.SCREEN_BRIGHTNESS, v.coerceIn(1, 255))
    }

    private fun audio(c: Context) = c.getSystemService(Context.AUDIO_SERVICE) as AudioManager

    fun volume(c: Context): Int = audio(c).getStreamVolume(AudioManager.STREAM_MUSIC)
    fun maxVolume(c: Context): Int = audio(c).getStreamMaxVolume(AudioManager.STREAM_MUSIC)
    fun setVolume(c: Context, v: Int) = audio(c).setStreamVolume(AudioManager.STREAM_MUSIC, v, 0)

    fun batteryPercent(c: Context): Int {
        val i = c.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) ?: return -1
        val l = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val s = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
        return if (l < 0) -1 else l * 100 / s
    }

    fun charging(c: Context): Boolean {
        val i = c.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) ?: return false
        val st = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        return st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL
    }
}
