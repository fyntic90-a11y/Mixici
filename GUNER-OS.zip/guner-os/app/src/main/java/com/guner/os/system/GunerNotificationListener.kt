package com.guner.os.system

import android.service.notification.NotificationListenerService

/**
 * Пустой сервис: его наличие и включённый пользователем «Доступ к уведомлениям»
 * даёт Центру управления право читать активные медиасессии (управление музыкой).
 * Экран блокировки с уведомлениями будет строиться на нём на этапе 7.
 */
class GunerNotificationListener : NotificationListenerService()
