package com.guner.os.ui

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.EnterTransition
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.guner.os.R
import com.guner.os.SettingsActivity
import com.guner.os.data.AppInfo
import com.guner.os.system.launchApp
import com.guner.os.system.startSafe
import com.guner.os.vm.LauncherViewModel
import kotlinx.coroutines.delay

private data class MenuTarget(val app: AppInfo, val inHome: Boolean, val inDock: Boolean)

@Composable
fun LauncherRoot(vm: LauncherViewModel, onBlur: (Int) -> Unit) {
    val ctx = LocalContext.current
    val view = LocalView.current
    val s by vm.settings.collectAsStateWithLifecycle()
    val allApps by vm.apps.collectAsStateWithLifecycle()
    val homeSignal by vm.homeSignal.collectAsStateWithLifecycle()

    val byKey = remember(allApps) { allApps.associateBy { it.key } }
    val visible = remember(allApps, s.hidden) { allApps.filter { it.key !in s.hidden } }
    val pages = remember(byKey, s.pages, s.hidden) {
        s.pages.map { p -> p.mapNotNull { byKey[it] }.filter { it.key !in s.hidden } }
    }
    val dock = remember(byKey, s.dock, s.hidden) {
        s.dock.mapNotNull { byKey[it] }.filter { it.key !in s.hidden }
    }

    var drawer by remember { mutableStateOf(false) }
    var cc by remember { mutableStateOf(false) }
    var menu by remember { mutableStateOf<MenuTarget?>(null) }
    var pageMenu by remember { mutableStateOf<Int?>(null) }
    var splash by rememberSaveable { mutableStateOf(true) }

    val factor by rememberUpdatedState(s.animFactor)
    fun dur(base: Int) = (base * factor).toInt().coerceAtLeast(1)

    val drawerP by animateFloatAsState(
        if (drawer) 1f else 0f, tween(dur(380), easing = FastOutSlowInEasing), label = "drawer"
    )
    val ccP by animateFloatAsState(
        if (cc) 1f else 0f, tween(dur(340), easing = FastOutSlowInEasing), label = "cc"
    )
    val drawerVisible by remember { derivedStateOf { drawerP > 0.001f } }
    val ccVisible by remember { derivedStateOf { ccP > 0.001f } }

    val blurOn = (drawer || cc) && s.perfMode == 2
    LaunchedEffect(blurOn) { onBlur(if (blurOn) 48 else 0) }

    LaunchedEffect(homeSignal) {
        if (homeSignal > 0) {
            drawer = false
            cc = false
            menu = null
            pageMenu = null
        }
    }
    LaunchedEffect(Unit) {
        delay(dur(1100).toLong())
        splash = false
    }

    val openSettingsScreen = { startSafe(ctx, Intent(ctx, SettingsActivity::class.java)) }
    val gesture: (Int) -> Unit = { action ->
        when (action) {
            1 -> drawer = true
            2 -> cc = true
            3 -> openSettingsScreen()
            else -> Unit
        }
    }
    val launch: (AppInfo, Rect?) -> Unit = { app, r ->
        launchApp(ctx, view, app, r, s.launchAnim)
        drawer = false
    }

    BackHandler(enabled = drawer || cc) {
        if (cc) cc = false else drawer = false
    }

    Box(Modifier.fillMaxSize()) {
        if (s.wallpaperMode == 1) {
            GunerWallpaper(s.wallpaperStyle, MaterialTheme.colorScheme.primary, animated = s.perfMode == 2)
        }
        // Затемнение сверху/снизу для читаемости подписей на любых обоях
        Box(
            Modifier.fillMaxSize().background(
                Brush.verticalGradient(
                    listOf(Color.Black.copy(alpha = 0.28f), Color.Transparent, Color.Black.copy(alpha = 0.38f))
                )
            )
        )

        HomeScreen(
            s = s, pages = pages, dock = dock, repo = vm.repo, homeSignal = homeSignal,
            onLaunch = launch,
            onMenu = { app, inDock ->
                menu = MenuTarget(app, inHome = s.pages.any { app.key in it }, inDock = inDock)
            },
            onGesture = gesture,
            onEmptyLong = { pageMenu = it },
            modifier = Modifier.graphicsLayer {
                alpha = 1f - 0.6f * drawerP
                val sc = 1f - 0.06f * drawerP
                scaleX = sc
                scaleY = sc
            },
        )

        if (drawerVisible) {
            AppDrawer(
                apps = visible, s = s, repo = vm.repo,
                onLaunch = launch,
                onLongClick = { app ->
                    menu = MenuTarget(app, inHome = s.pages.any { app.key in it }, inDock = app.key in s.dock)
                },
                onClose = { drawer = false },
                modifier = Modifier.fillMaxSize().graphicsLayer {
                    translationY = (1f - drawerP) * size.height
                    alpha = (drawerP * 1.6f).coerceAtMost(1f)
                },
            )
        }

        if (ccVisible) {
            ControlCenter(
                progress = { ccP },
                onClose = { cc = false },
                onOpenSettings = { cc = false; openSettingsScreen() },
            )
        }

        AnimatedVisibility(
            visible = splash,
            enter = EnterTransition.None,
            exit = fadeOut(tween(dur(400))) + scaleOut(tween(dur(400)), targetScale = 1.08f),
        ) { SplashScreen() }
    }

    menu?.let { m ->
        val a = m.app
        val acts = buildList<Pair<String, () -> Unit>> {
            if (m.inHome) add("Убрать с рабочего стола" to { vm.removeFromHome(a.key) })
            else add("На рабочий стол" to { vm.addToHome(a.key) })
            if (m.inDock) add("Убрать из дока" to { vm.removeFromDock(a.key) })
            else if (s.dock.size < 5) add("В док" to { vm.addToDock(a.key) })
            add("Скрыть" to { vm.hide(a.key) })
            add("О приложении" to {
                startSafe(ctx, Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${a.packageName}")))
            })
            add("Удалить" to {
                startSafe(ctx, Intent(Intent.ACTION_DELETE, Uri.parse("package:${a.packageName}")))
            })
        }
        ActionDialog(a.label, acts) { menu = null }
    }

    pageMenu?.let { idx ->
        val acts = buildList<Pair<String, () -> Unit>> {
            add("Добавить страницу" to { vm.addPage() })
            if (s.pages.size > 1 && s.pages.getOrNull(idx)?.isEmpty() == true) {
                add("Удалить пустую страницу" to { vm.removePage(idx) })
            }
            add("Настройки GUNER" to { openSettingsScreen() })
        }
        ActionDialog("Рабочий стол", acts) { pageMenu = null }
    }
}

@Composable
private fun ActionDialog(title: String, actions: List<Pair<String, () -> Unit>>, onDismiss: () -> Unit) {
    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(28.dp),
            color = MaterialTheme.colorScheme.surface.copy(alpha = 0.97f),
            tonalElevation = 6.dp,
        ) {
            Column(Modifier.padding(vertical = 12.dp)) {
                Text(
                    title,
                    modifier = Modifier.padding(horizontal = 24.dp, vertical = 12.dp),
                    style = MaterialTheme.typography.titleMedium,
                    maxLines = 1,
                )
                actions.forEach { (label, act) ->
                    Text(
                        label,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { act(); onDismiss() }
                            .padding(horizontal = 24.dp, vertical = 14.dp),
                        style = MaterialTheme.typography.bodyLarge,
                    )
                }
            }
        }
    }
}

@Composable
private fun SplashScreen() {
    val scale = remember { Animatable(0.6f) }
    val fade = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        fade.animateTo(1f, tween(450))
    }
    LaunchedEffect(Unit) {
        scale.animateTo(1f, spring(dampingRatio = 0.55f, stiffness = 180f))
    }
    Box(
        Modifier.fillMaxSize().background(Color(0xFF0A0B0F)).blockTouches(),
        contentAlignment = Alignment.Center,
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.graphicsLayer {
                scaleX = scale.value
                scaleY = scale.value
                alpha = fade.value
            },
        ) {
            Image(painterResource(R.drawable.ic_launcher_foreground), contentDescription = null, modifier = Modifier.size(140.dp))
            Spacer(Modifier.height(8.dp))
            Text("GUNER OS", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Light, letterSpacing = 8.sp)
        }
    }
}
