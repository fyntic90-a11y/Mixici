package com.guner.os.ui

import android.text.format.DateFormat
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import com.guner.os.data.AppInfo
import com.guner.os.data.AppRepository
import com.guner.os.data.GunerSettings
import kotlinx.coroutines.delay
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlin.math.absoluteValue

@Composable
fun HomeScreen(
    s: GunerSettings,
    pages: List<List<AppInfo>>,
    dock: List<AppInfo>,
    repo: AppRepository,
    homeSignal: Int,
    onLaunch: (AppInfo, Rect?) -> Unit,
    onMenu: (AppInfo, Boolean) -> Unit,
    onGesture: (Int) -> Unit,
    onEmptyLong: (Int) -> Unit,
    modifier: Modifier = Modifier,
) {
    val count by rememberUpdatedState(pages.size.coerceAtLeast(1))
    val pager = rememberPagerState { count }
    LaunchedEffect(homeSignal) {
        if (homeSignal > 0) pager.animateScrollToPage(0)
    }

    Column(
        modifier
            .fillMaxSize()
            .pointerInput(s.swipeUp, s.swipeDown) {
                var total = 0f
                val threshold = 64.dp.toPx()
                detectVerticalDragGestures(
                    onDragStart = { total = 0f },
                    onDragEnd = {
                        if (total < -threshold) onGesture(s.swipeUp)
                        else if (total > threshold) onGesture(s.swipeDown)
                    },
                    onDragCancel = {},
                    onVerticalDrag = { _, dy -> total += dy },
                )
            }
            .statusBarsPadding()
    ) {
        if (s.showClock) ClockWidget()

        HorizontalPager(state = pager, modifier = Modifier.weight(1f)) { page ->
            val items = pages.getOrNull(page).orEmpty()
            Box(
                Modifier
                    .fillMaxSize()
                    .graphicsLayer {
                        val o = ((pager.currentPage - page) + pager.currentPageOffsetFraction)
                            .absoluteValue.coerceIn(0f, 1f)
                        alpha = 1f - 0.5f * o
                        val sc = 1f - 0.1f * o
                        scaleX = sc
                        scaleY = sc
                    }
                    .pointerInput(page) { detectTapGestures(onLongPress = { onEmptyLong(page) }) }
            ) {
                Column(Modifier.fillMaxSize().padding(horizontal = 12.dp)) {
                    repeat(s.rows) { r ->
                        Row(Modifier.weight(1f).fillMaxWidth()) {
                            repeat(s.cols) { c ->
                                Box(Modifier.weight(1f).fillMaxHeight(), contentAlignment = Alignment.Center) {
                                    items.getOrNull(r * s.cols + c)?.let { app ->
                                        AppIcon(
                                            app = app, s = s, repo = repo, showLabel = s.showLabels,
                                            onClick = { b -> onLaunch(app, b) },
                                            onLongClick = { onMenu(app, false) },
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        if (pages.size > 1) {
            Row(
                Modifier.align(Alignment.CenterHorizontally).padding(vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                repeat(pages.size) { i ->
                    val sel = pager.currentPage == i
                    val w by animateDpAsState(if (sel) 18.dp else 6.dp, label = "dot")
                    Box(
                        Modifier
                            .padding(horizontal = 3.dp)
                            .height(6.dp)
                            .width(w)
                            .clip(CircleShape)
                            .background(Color.White.copy(alpha = if (sel) 0.95f else 0.4f))
                    )
                }
            }
        }

        if (dock.isNotEmpty()) {
            GlassPanel(
                Modifier
                    .navigationBarsPadding()
                    .padding(horizontal = 16.dp, vertical = 8.dp)
                    .fillMaxWidth()
            ) {
                Row(
                    Modifier.fillMaxWidth().heightIn(min = 80.dp).padding(horizontal = 8.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    dock.forEach { app ->
                        AppIcon(
                            app = app, s = s, repo = repo, showLabel = false,
                            onClick = { b -> onLaunch(app, b) },
                            onLongClick = { onMenu(app, true) },
                        )
                    }
                }
            }
        } else {
            Box(Modifier.navigationBarsPadding().height(16.dp))
        }
    }
}

@Composable
fun ClockWidget() {
    val ctx = LocalContext.current
    var now by remember { mutableStateOf(LocalDateTime.now()) }
    LaunchedEffect(Unit) {
        while (true) {
            now = LocalDateTime.now()
            delay(60_000L - (System.currentTimeMillis() % 60_000L) + 50L)
        }
    }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { now = LocalDateTime.now() }
    val is24 = DateFormat.is24HourFormat(ctx)
    val time = now.format(DateTimeFormatter.ofPattern(if (is24) "HH:mm" else "h:mm", Locale.getDefault()))
    val date = now.format(DateTimeFormatter.ofPattern("EEEE, d MMMM", Locale.getDefault()))
    val shadow = Shadow(Color.Black.copy(alpha = 0.5f), blurRadius = 10f)
    Column(Modifier.padding(horizontal = 28.dp, vertical = 12.dp)) {
        Text(
            time, color = Color.White, fontSize = 64.sp, fontWeight = FontWeight.Light,
            style = TextStyle(shadow = shadow),
        )
        Text(
            date.replaceFirstChar { it.uppercase() }, color = Color.White.copy(alpha = 0.9f), fontSize = 16.sp,
            style = TextStyle(shadow = shadow),
        )
    }
}
