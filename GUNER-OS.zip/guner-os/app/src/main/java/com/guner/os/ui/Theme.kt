package com.guner.os.ui

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.platform.LocalContext
import com.guner.os.data.GunerSettings

val GunerAccents = listOf(0xFFC6FF3DL, 0xFF4D8DFFL, 0xFFFF6B5EL, 0xFFA77BFFL, 0xFFFFB020L)

@Composable
fun GunerTheme(s: GunerSettings, content: @Composable () -> Unit) {
    val dark = when (s.themeMode) {
        1 -> false
        2 -> true
        else -> isSystemInDarkTheme()
    }
    val ctx = LocalContext.current
    val accent = Color(GunerAccents[s.accent.coerceIn(0, GunerAccents.lastIndex)])
    val scheme = when {
        s.dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S ->
            if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
        dark -> darkColorScheme(
            primary = accent,
            onPrimary = Color.Black,
            primaryContainer = accent.copy(alpha = 0.25f),
            onPrimaryContainer = accent,
            secondary = accent,
            background = Color(0xFF0E0F13),
            onBackground = Color(0xFFEDEDF0),
            surface = Color(0xFF16171C),
            onSurface = Color(0xFFEDEDF0),
            surfaceVariant = Color(0xFF24262D),
            onSurfaceVariant = Color(0xFFB7B9C2),
        )
        else -> lightColorScheme(
            primary = lerp(accent, Color.Black, 0.35f),
            onPrimary = Color.White,
            primaryContainer = accent.copy(alpha = 0.35f),
            secondary = lerp(accent, Color.Black, 0.35f),
            background = Color(0xFFF6F6F8),
            onBackground = Color(0xFF15161A),
            surface = Color(0xFFFFFFFF),
            onSurface = Color(0xFF15161A),
            surfaceVariant = Color(0xFFE9EAEF),
            onSurfaceVariant = Color(0xFF50525C),
        )
    }
    MaterialTheme(colorScheme = scheme, content = content)
}
