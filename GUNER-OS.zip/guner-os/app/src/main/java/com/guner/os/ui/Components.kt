package com.guner.os.ui

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.boundsInWindow
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.guner.os.data.AppInfo
import com.guner.os.data.AppRepository
import com.guner.os.data.GunerSettings

/** Поглощает все касания, чтобы слои под панелью не реагировали. */
fun Modifier.blockTouches(): Modifier = pointerInput(Unit) {
    awaitPointerEventScope {
        while (true) {
            awaitPointerEvent().changes.forEach { it.consume() }
        }
    }
}

fun iconShape(s: GunerSettings): Shape = when (s.iconShape) {
    0 -> CircleShape
    1 -> RoundedCornerShape(percent = 30)
    else -> RoundedCornerShape(percent = 16)
}

@Composable
fun GlassPanel(
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(28.dp),
    alpha: Float = 0.55f,
    content: @Composable BoxScope.() -> Unit,
) {
    Box(
        modifier = modifier
            .clip(shape)
            .background(MaterialTheme.colorScheme.surface.copy(alpha = alpha))
            .background(Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.10f), Color.Transparent)))
            .border(1.dp, Color.White.copy(alpha = 0.18f), shape),
        content = content,
    )
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun AppIcon(
    app: AppInfo,
    s: GunerSettings,
    repo: AppRepository,
    showLabel: Boolean,
    onClick: (Rect?) -> Unit,
    onLongClick: () -> Unit,
    modifier: Modifier = Modifier,
    labelColor: Color = Color.White,
    shadow: Boolean = true,
) {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val scale by animateFloatAsState(
        if (pressed) 0.86f else 1f,
        spring(dampingRatio = 0.55f, stiffness = 500f),
        label = "press",
    )
    var bounds by remember { mutableStateOf<Rect?>(null) }
    val bmp by produceState(repo.cached(app.key), app.key) {
        if (value == null) value = repo.icon(app)
    }
    Column(
        modifier = modifier
            .onGloballyPositioned { bounds = it.boundsInWindow() }
            .graphicsLayer { scaleX = scale; scaleY = scale }
            .combinedClickable(
                interactionSource = src,
                indication = null,
                onClick = { onClick(bounds) },
                onLongClick = onLongClick,
            )
            .padding(4.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(Modifier.size(s.iconSize.dp).clip(iconShape(s))) {
            bmp?.let { Image(it, contentDescription = app.label, modifier = Modifier.fillMaxSize()) }
        }
        if (showLabel) {
            Text(
                app.label,
                color = labelColor,
                fontSize = 11.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                style = if (shadow) TextStyle(shadow = Shadow(Color.Black.copy(alpha = 0.6f), blurRadius = 6f)) else TextStyle.Default,
                modifier = Modifier.padding(top = 4.dp).widthIn(max = (s.iconSize + 20).dp),
            )
        }
    }
}

private fun DrawScope.glow(c: Color, x: Float, y: Float, r: Float) {
    drawCircle(
        brush = Brush.radialGradient(listOf(c, Color.Transparent), center = Offset(x, y), radius = r),
        radius = r,
        center = Offset(x, y),
    )
}

/** Фирменные обои GUNER. В режиме «Максимальная красота» медленно «дышат» (анимация только в фазе рисования). */
@Composable
fun GunerWallpaper(style: Int, accent: Color, animated: Boolean) {
    val t = if (animated) {
        rememberInfiniteTransition(label = "wp").animateFloat(
            0f, 1f,
            infiniteRepeatable(tween(24000, easing = LinearEasing), RepeatMode.Reverse),
            label = "t",
        )
    } else null
    Canvas(Modifier.fillMaxSize()) {
        val p = t?.value ?: 0.5f
        val w = size.width
        val h = size.height
        drawRect(Color(0xFF0A0B0F))
        when (style) {
            0 -> {
                glow(accent.copy(alpha = 0.55f), w * (0.15f + 0.3f * p), h * 0.22f, w * 0.95f)
                glow(Color(0xFF6A3DFF).copy(alpha = 0.35f), w * (0.9f - 0.2f * p), h * 0.85f, w * 0.9f)
            }
            1 -> drawRect(
                Brush.verticalGradient(listOf(accent.copy(alpha = 0.45f), Color(0xFF0A0B0F)), startY = h * 0.6f * p, endY = h)
            )
            2 -> {
                glow(accent.copy(alpha = 0.40f), w * 0.2f, h * (0.2f + 0.2f * p), w * 0.8f)
                glow(Color(0xFF00E5FF).copy(alpha = 0.28f), w * 0.85f, h * (0.5f - 0.15f * p), w * 0.8f)
                glow(Color(0xFFFF4DA6).copy(alpha = 0.25f), w * 0.4f, h * 0.95f, w * 0.9f)
            }
            else -> {
                drawRect(Color.Black)
                glow(accent.copy(alpha = 0.30f), w * 0.5f, h * (1.05f - 0.05f * p), w * 0.8f)
            }
        }
    }
}
