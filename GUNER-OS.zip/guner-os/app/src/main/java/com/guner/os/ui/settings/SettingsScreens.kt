package com.guner.os.ui.settings

import android.content.Intent
import android.os.Build
import android.provider.Settings
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Apps
import androidx.compose.material.icons.rounded.Gesture
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.Palette
import androidx.compose.material.icons.rounded.Speed
import androidx.compose.material.icons.rounded.VisibilityOff
import androidx.compose.material.icons.rounded.Wallpaper
import androidx.compose.material.icons.rounded.Animation
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.guner.os.R
import com.guner.os.data.GunerSettings
import com.guner.os.data.SK
import com.guner.os.system.startSafe
import com.guner.os.ui.GunerAccents
import com.guner.os.vm.LauncherViewModel

private val TITLES = mapOf(
    "root" to "GUNER Настройки",
    "personal" to "Персонализация",
    "wallpaper" to "Обои",
    "icons" to "Иконки",
    "anim" to "Анимации",
    "home" to "Рабочий стол",
    "gestures" to "Жесты",
    "perf" to "Производительность",
    "hidden" to "Скрытые приложения",
    "about" to "О системе",
)

@Composable
fun SettingsApp(vm: LauncherViewModel, s: GunerSettings, onExit: () -> Unit) {
    var screen by rememberSaveable { mutableStateOf("root") }
    BackHandler(enabled = screen != "root") { screen = "root" }

    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Column(Modifier.fillMaxSize().statusBarsPadding()) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                IconButton(onClick = { if (screen == "root") onExit() else screen = "root" }) {
                    Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Назад")
                }
                Text(TITLES[screen] ?: "", style = MaterialTheme.typography.headlineSmall)
            }
            AnimatedContent(
                targetState = screen,
                modifier = Modifier.weight(1f),
                transitionSpec = { fadeIn(tween(200)) togetherWith fadeOut(tween(120)) },
                label = "settings-screen",
            ) { sc ->
                Column(
                    Modifier
                        .fillMaxSize()
                        .verticalScroll(rememberScrollState())
                        .padding(horizontal = 20.dp, vertical = 8.dp)
                        .navigationBarsPadding()
                ) {
                    when (sc) {
                        "personal" -> PersonalScreen(vm, s)
                        "wallpaper" -> WallpaperScreen(vm, s)
                        "icons" -> IconsScreen(vm, s)
                        "anim" -> AnimScreen(vm, s)
                        "home" -> HomeSettingsScreen(vm, s)
                        "gestures" -> GesturesScreen(vm, s)
                        "perf" -> PerfScreen(vm, s)
                        "hidden" -> HiddenScreen(vm, s)
                        "about" -> AboutScreen()
                        else -> RootScreen { screen = it }
                    }
                    Spacer(Modifier.height(24.dp))
                }
            }
        }
    }
}

// ---------- Экраны ----------

@Composable
private fun RootScreen(go: (String) -> Unit) {
    val ctx = LocalContext.current
    val isDefault = remember {
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        val r = ctx.packageManager.resolveActivity(i, android.content.pm.PackageManager.MATCH_DEFAULT_ONLY)
        r?.activityInfo?.packageName == ctx.packageName
    }
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(28.dp))
            .background(MaterialTheme.colorScheme.primaryContainer)
            .padding(20.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Image(painterResource(R.drawable.ic_launcher_foreground), null, Modifier.size(64.dp).background(Color(0xFF0A0B0F), CircleShape))
        Spacer(Modifier.width(16.dp))
        Column(Modifier.weight(1f)) {
            Text("GUNER OS", fontSize = 20.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onPrimaryContainer)
            Text(
                if (isDefault) "GUNER Launcher — основной рабочий стол" else "GUNER Launcher не выбран основным",
                fontSize = 13.sp, color = MaterialTheme.colorScheme.onPrimaryContainer,
            )
        }
    }
    Spacer(Modifier.height(12.dp))
    NavRow(Icons.Rounded.Palette, "Персонализация", "Тема, цвета, акцент") { go("personal") }
    NavRow(Icons.Rounded.Wallpaper, "Обои", "Системные или фирменные GUNER") { go("wallpaper") }
    NavRow(Icons.Rounded.Apps, "Иконки", "Форма, размер, подписи") { go("icons") }
    NavRow(Icons.Rounded.Animation, "Анимации", "Скорость и открытие приложений") { go("anim") }
    NavRow(Icons.Rounded.Home, "Рабочий стол", "Сетка, часы, основной лаунчер") { go("home") }
    NavRow(Icons.Rounded.Gesture, "Жесты", "Свайп вверх и вниз") { go("gestures") }
    NavRow(Icons.Rounded.Speed, "Производительность", "Режимы работы, кэш") { go("perf") }
    NavRow(Icons.Rounded.VisibilityOff, "Скрытые приложения", "Вернуть скрытое") { go("hidden") }
    NavRow(Icons.Rounded.Info, "О системе", "Версия и возможности") { go("about") }
}

@Composable
private fun PersonalScreen(vm: LauncherViewModel, s: GunerSettings) {
    ChoiceRow("Тема", listOf("Системная", "Светлая", "Тёмная"), s.themeMode) { vm.put(SK.theme, it) }
    val dynOk = Build.VERSION.SDK_INT >= Build.VERSION_CODES.S
    SwitchRow(
        "Динамические цвета (Material You)",
        if (dynOk) "Цвета из системных обоев" else "Доступно на Android 12 и новее",
        s.dynamicColor && dynOk, enabled = dynOk,
    ) { vm.put(SK.dynamic, it) }
    Label("Акцентный цвет")
    Text(
        "Используется, когда динамические цвета выключены или недоступны.",
        fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
    )
    Spacer(Modifier.height(8.dp))
    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        GunerAccents.forEachIndexed { i, c ->
            Box(
                Modifier
                    .size(44.dp)
                    .clip(CircleShape)
                    .background(Color(c))
                    .border(if (s.accent == i) 3.dp else 0.dp, MaterialTheme.colorScheme.onSurface, CircleShape)
                    .clickable { vm.put(SK.accent, i) }
            )
        }
    }
}

@Composable
private fun WallpaperScreen(vm: LauncherViewModel, s: GunerSettings) {
    val ctx = LocalContext.current
    ChoiceRow("Источник обоев", listOf("Системные", "GUNER"), s.wallpaperMode) { vm.put(SK.wpMode, it) }
    if (s.wallpaperMode == 1) {
        ChoiceRow("Стиль GUNER", listOf("Свечение", "Градиент", "Аврора", "AMOLED"), s.wallpaperStyle) { vm.put(SK.wpStyle, it) }
        Text(
            "Фирменные обои рисуются внутри лаунчера. В режиме «Максимальная красота» они медленно анимируются.",
            fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    } else {
        Spacer(Modifier.height(8.dp))
        Button(onClick = { startSafe(ctx, Intent.createChooser(Intent(Intent.ACTION_SET_WALLPAPER), "Выбрать обои")) }) {
            Text("Выбрать системные обои")
        }
    }
}

@Composable
private fun IconsScreen(vm: LauncherViewModel, s: GunerSettings) {
    ChoiceRow("Форма иконок", listOf("Круг", "Сквиркл", "Квадрат"), s.iconShape) { vm.put(SK.iconShape, it) }
    SliderRow("Размер иконок: ${s.iconSize} dp", s.iconSize.toFloat(), 44f..72f, 6) { vm.put(SK.iconSize, it.toInt()) }
    SwitchRow("Подписи под иконками", null, s.showLabels) { vm.put(SK.labels, it) }
}

@Composable
private fun AnimScreen(vm: LauncherViewModel, s: GunerSettings) {
    SliderRow(
        "Длительность анимаций: ×${"%.2f".format(s.animScale)}",
        s.animScale, 0.25f..2f, 6,
    ) { vm.put(SK.animScale, it) }
    Text("Меньше — быстрее. 1.00 — стандарт.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
    SwitchRow("Анимация открытия приложений", "Раскрытие из иконки", s.launchAnim) { vm.put(SK.launchAnim, it) }
}

@Composable
private fun HomeSettingsScreen(vm: LauncherViewModel, s: GunerSettings) {
    val ctx = LocalContext.current
    val presets = listOf(4 to 5, 5 to 5, 5 to 6)
    val sel = presets.indexOf(s.cols to s.rows).coerceAtLeast(0)
    ChoiceRow("Сетка", presets.map { "${it.first}×${it.second}" }, sel) {
        vm.put(SK.cols, presets[it].first)
        vm.put(SK.rows, presets[it].second)
    }
    SwitchRow("Часы и дата на рабочем столе", null, s.showClock) { vm.put(SK.clock, it) }
    Spacer(Modifier.height(8.dp))
    Text(
        "Долгое нажатие на пустое место — новая страница. Долгое нажатие на иконку — меню.",
        fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
    )
    Spacer(Modifier.height(16.dp))
    Button(onClick = { startSafe(ctx, Intent(Settings.ACTION_HOME_SETTINGS)) }) {
        Text("Сделать GUNER Launcher основным")
    }
}

@Composable
private fun GesturesScreen(vm: LauncherViewModel, s: GunerSettings) {
    val opts = listOf("Ничего", "Приложения", "Центр управления", "Настройки")
    ChoiceRow("Свайп вверх на рабочем столе", opts, s.swipeUp) { vm.put(SK.swipeUp, it) }
    ChoiceRow("Свайп вниз на рабочем столе", opts, s.swipeDown) { vm.put(SK.swipeDown, it) }
    Text(
        "Двойной тап для блокировки экрана и шторка уведомлений системы требуют привилегий, " +
            "недоступных обычному APK (Accessibility/Device Admin) — они не включены намеренно.",
        fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
    )
}

@Composable
private fun PerfScreen(vm: LauncherViewModel, s: GunerSettings) {
    val ctx = LocalContext.current
    ChoiceRow("Режим", listOf("Производительность", "Баланс", "Красота"), s.perfMode) { vm.put(SK.perf, it) }
    val desc = when (s.perfMode) {
        0 -> "Анимации короче на 25%, без размытия и без живых обоев. Для 4 ГБ RAM и слабых процессоров."
        1 -> "Стандартные анимации, статичные обои, без размытия. Оптимально для большинства телефонов."
        else -> "Размытие фона за панелями (Android 12+, если поддерживается устройством) и живые обои GUNER."
    }
    Text(desc, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
    Spacer(Modifier.height(16.dp))
    OutlinedButton(onClick = {
        vm.repo.clearIcons()
        Toast.makeText(ctx, "Кэш иконок очищен", Toast.LENGTH_SHORT).show()
    }) { Text("Очистить кэш иконок") }
}

@Composable
private fun HiddenScreen(vm: LauncherViewModel, s: GunerSettings) {
    val apps by vm.apps.collectAsStateWithLifecycle()
    val hidden = apps.filter { it.key in s.hidden }
    if (hidden.isEmpty()) {
        Text("Скрытых приложений нет.", color = MaterialTheme.colorScheme.onSurfaceVariant)
    } else {
        hidden.forEach { app ->
            Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(app.label, Modifier.weight(1f), fontSize = 16.sp)
                TextButton(onClick = { vm.unhide(app.key) }) { Text("Показать") }
            }
        }
    }
}

@Composable
private fun AboutScreen() {
    val ctx = LocalContext.current
    val ver = remember {
        try {
            ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName ?: "?"
        } catch (e: Exception) {
            "?"
        }
    }
    Row(verticalAlignment = Alignment.CenterVertically) {
        Image(painterResource(R.drawable.ic_launcher_foreground), null, Modifier.size(88.dp).background(Color(0xFF0A0B0F), CircleShape))
        Spacer(Modifier.width(16.dp))
        Column {
            Text("GUNER OS", fontSize = 24.sp, fontWeight = FontWeight.SemiBold)
            Text("GUNER Launcher $ver", color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
    Spacer(Modifier.height(20.dp))
    InfoLine("Пакет", ctx.packageName)
    InfoLine("Android", "${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})")
    InfoLine("Устройство", "${Build.MANUFACTURER} ${Build.MODEL}")
    Spacer(Modifier.height(20.dp))
    Text(
        "GUNER OS — оболочка уровня приложения: лаунчер, центр управления и настройки. " +
            "Она не заменяет прошивку. Экран блокировки, AOD, биометрия и виджеты — в разработке (этапы 6–8).",
        fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
    )
}

// ---------- Строительные блоки ----------

@Composable
private fun NavRow(icon: ImageVector, title: String, sub: String, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(icon, null, tint = MaterialTheme.colorScheme.primary)
        Spacer(Modifier.width(16.dp))
        Column {
            Text(title, style = MaterialTheme.typography.titleMedium)
            Text(sub, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun Label(text: String) {
    Text(text, style = MaterialTheme.typography.titleSmall, modifier = Modifier.padding(top = 16.dp, bottom = 8.dp))
}

@Composable
private fun ChoiceRow(title: String, options: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    Label(title)
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        options.forEachIndexed { i, o ->
            FilterChip(selected = i == selected, onClick = { onSelect(i) }, label = { Text(o) })
        }
    }
}

@Composable
private fun SwitchRow(
    title: String,
    sub: String?,
    checked: Boolean,
    enabled: Boolean = true,
    onChange: (Boolean) -> Unit,
) {
    Row(Modifier.fillMaxWidth().padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge)
            if (sub != null) Text(sub, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(checked = checked, onCheckedChange = onChange, enabled = enabled)
    }
}

@Composable
private fun SliderRow(title: String, value: Float, range: ClosedFloatingPointRange<Float>, steps: Int, onDone: (Float) -> Unit) {
    var v by remember(value) { mutableFloatStateOf(value) }
    Label(title)
    Slider(value = v, onValueChange = { v = it }, valueRange = range, steps = steps, onValueChangeFinished = { onDone(v) })
}

@Composable
private fun InfoLine(k: String, v: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Text(k, Modifier.width(110.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(v)
    }
}
